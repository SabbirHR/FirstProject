package bd.edu.seu.giftorderservice.exception;

public class ResourceNotFoundException extends Exception {
}
