package bd.edu.seu.giftorderservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GiftOrderServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(GiftOrderServiceApplication.class, args);
	}

}
