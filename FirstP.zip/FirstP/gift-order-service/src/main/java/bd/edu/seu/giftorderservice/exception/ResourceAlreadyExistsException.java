package bd.edu.seu.giftorderservice.exception;

public class ResourceAlreadyExistsException extends Exception {
}
